1. Make sure you have 'nodejs' installed:
https://nodejs.org/en

2. Add the 'data' directory from here: [link]

3. Open the terminal inside the 'node' directory

4. Run the following command:
npm install

5. You can now open 'viewer.html'